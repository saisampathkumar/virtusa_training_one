export class Product {
    sku:string
    name:string
    description:string
    image:string
    price:number
    rating:number
}
