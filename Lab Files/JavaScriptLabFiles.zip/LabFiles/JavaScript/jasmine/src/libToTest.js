/*
    Functions to test
*/
function returnTrue() {
   console.log("returnTrue function entered ...");
   return true;
}
