describe("Unit Test Suite #1", function() {

   beforeEach(function() {
      console.log("The Unit Test Suite #1 is running ...");
   });

   it("testing truth and false return values (Unit Test #1)", function() {
      console.log("  Unit Test #1 running... ");
      
      
   });
});
