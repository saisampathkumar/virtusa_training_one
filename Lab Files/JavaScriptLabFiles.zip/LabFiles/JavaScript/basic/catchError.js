window.onload = initAll;

function initAll() {	
	var ans = prompt("Enter a positive number","");

	
	
}